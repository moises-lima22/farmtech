import os


def limpar_console():
    os.system("cls" if os.name == "nt" else "clear")
